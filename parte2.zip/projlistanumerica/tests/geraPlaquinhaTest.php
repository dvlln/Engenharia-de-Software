<?php

    namespace ENGA5;

    use PHPUnit\Framework\TestCase;

    class geraPlaquinhaTest extends TestCase{

        /**
         * @dataProvider additionProvider
        */
        public function testVerificaQuantidadeValores($valor, $expected){
            $plaquinha = new geraPlaquinha;
            $this->assertEquals($expected, $plaquinha->validaPlaquinha($valor));
        }

        public function additionProvider(): array{
            return[         'Placa 1' => ['WFE1234', 'Válido'],
                          'Placa 2' => ['ÊÃÚ1564', 'Inválido'],
                           'Placa 3' => ['013241', 'Inválido'],
                          'Placa 4' => ['EFG@120', 'Inválido']
            ];
        }
    }
?>