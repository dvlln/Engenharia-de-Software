<?php

namespace ENGA5;

class ListaNumerica{
    private $valores;

    public function setValores($valores){
        $this->valores = $valores;
    }

    public function getValores(){
        return $this->valores;
    }

    public function verificaQuantidade(){
        $tam = sizeof($this->valores);
        if($tam >= 4 && $tam <= 10){
            return 'Válido';
        }
        return 'Inválido';
    }

    public function verificaValores(){
        if($this->valores == null){
            return 'Inválido';
        }
        

        foreach($this->valores as $valor){
            if($valor < 10000 || $valor > 99999){
                return 'Inválido';
            }
        }

        return 'Válido';
    }

    public function validaValores(){
        if($this->verificaQuantidade() == 'Válido' && $this->verificaValores() == 'Válido'){
            return 'Válido';
        } else{
            return 'Inválido';
        }
    }
}
?>