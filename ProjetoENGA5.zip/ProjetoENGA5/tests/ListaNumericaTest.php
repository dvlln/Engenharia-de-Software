<?php

    namespace ENGA5;

    use PHPUnit\Framework\TestCase;

    class ListaNumericaTest extends TestCase{

        /**
         * @dataProvider additionProvider
        */
        public function testVerificaQuantidadeValores($vet, $expected){
            $ln = new ListaNumerica;
            $ln->setValores($vet);
            $this->assertEquals($expected, $ln->validaValores());
        }

         public function additionProvider(): array{
            return['verificaQuantidade' => [[12345,12345,12345], 'Inválido'],
                      'verificaValores' => [[1234,12345,12345], 'Inválido'],
 'verificaQuantidade e verificaValores' => [[1234,12345,12345,12345,12345], 'Inválido'],
 'verificaQuantidade e verificaValores' => [[12345,12345,12345,12345,12345], 'Válido']
            ];
        }
        
        // public function testValidaValores(){
        //     $ln = new ListaNumerica;
        //     $ln->setValores([15922, 15648, 13546, 19685]);
        //     $this->assertEquals('Inválido', $ln->validaValores());
        // }
    }
?>