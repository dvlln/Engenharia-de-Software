<?php

    namespace ENGA5;

    use PHPUnit\Framework\TestCase;
    use ENGA5\projlistanumerica\src\geraPlaquinha;

//testador antigo
    // class geraPlaquinhaTest extends TestCase{

    //     /**
    //      * @dataProvider additionProvider
    //     */
    //     public function testVerificaQuantidadeValores($vet, $expected){
    //         $ln = new ListaNumerica;
    //         $ln->setValores($vet);
    //         $this->assertEquals($expected, $ln->validaValores());
    //     }

    //      public function additionProvider(): array{
    //         return['plaquinha' => [[], 'Inválido']
    //         ];
    //     }
    // }
//

    // $gp = new geraPlaquinha;
    echo geraPlaquinha->validaPlaquinha();
?>