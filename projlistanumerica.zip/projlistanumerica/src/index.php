<?php

    phpinfo();

?>