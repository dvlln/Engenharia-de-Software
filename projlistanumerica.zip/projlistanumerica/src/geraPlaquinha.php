<?php

namespace ENGA5;

class geraPlaquinha{
    private $valores;

    public function setValores($valores){
        $this->valores = $valores;
    }

    public function getValores(){
        return $this->valores;
    }

    public function getNumber(){
        $number = substr(str_shuffle(str_repeat("0132456789", 4)), 0, 4);
        return $number;
    }

    public function getLetter(){
        $char = substr(str_shuffle(str_repeat("ABCDEFGHIJKLMNOPQRSTUVXWYZ", 3)), 0, 3);
        return $char;
    }

    public function validaPlaquinha(){
        // $pattern = '/[A-Za-z]{3}[0-9]{4}/';
        $number = $this->getNumber();
        $letter = $this->getLetter();
	    $subject = `$letter$number`;
	    // $result = preg_match( $pattern, $subject , $matches );
	    // if($result==1){
        //     print_r($matches);
        // }else{
        //     echo "Placa invalida";
        // }
        return $subject;
    }
}
?>